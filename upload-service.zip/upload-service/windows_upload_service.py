from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import tempfile
import subprocess
import tkinter as tk
import sys
from threading import Thread

#Create the GUI
root = tk.Tk()
root.title("Upload-Service")

def exit_application():
    root.destroy()
    sys.exit()
    

state_label = tk.Label(root, text="Lädt...", fg="red")
state_label.pack(pady=10) 

input_label = tk.Label(root, text="Port COM-Nr:")
input_label.pack()
input_entry = tk.Entry(root)
input_entry.pack(pady=5)


close_button = tk.Button(root, text="Schließen", command=exit_application)
close_button.pack(pady=10)

root.protocol("WM_DELETE_WINDOW", exit_application)


def compile_and_upload(port, fqbn, code):
    try:
        # temporary folder for the sketch
        with tempfile.TemporaryDirectory() as temp_dir:
            sketch_path = os.path.join(temp_dir, os.path.basename(temp_dir) + ".ino")
            arduino_cli_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "arduino-cli.exe")

            # Code file
            with open(sketch_path, "w") as sketch_file:
                sketch_file.write(code)
            
            compile_cmd = [
                arduino_cli_path, "compile",
                "--fqbn", fqbn,
                temp_dir
            ]
            #BA: Problem cp1252 codierung standard aber brauchte utf-8 sonst funktional aber fehlermeldung
            compile_result = subprocess.run(compile_cmd, capture_output=True, text=True, encoding='utf-8')

            #Check if the compilation was successful
            if compile_result.returncode != 0:
                return {'state': 'error', 'message': f'Compilation failed: {compile_result.stderr}'}

  
            upload_cmd = [
                arduino_cli_path, "upload",
                "-p", port,
                "--fqbn", fqbn,
                temp_dir
            ]
            upload_result = subprocess.run(upload_cmd, capture_output=True, text=True)

            #Check if the upload was successful
            if upload_result.returncode != 0:
                return {'state': 'error', 'message': f'Upload failed: {upload_result.stderr}'}

            return {'state': 'success', 'message': 'Upload successful'}

    except Exception as e:
        return {'state': 'error', 'message': e}

class SimplePostApiHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def do_GET(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()
        
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')

        def send_response(code, message):
            self.send_response(code)
            self._send_cors_headers()
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(message).encode('utf-8'))

        try:
            data = json.loads(post_data)
            port = input_entry.get()

            # Check if the required parameters are present
            if(port == ""):
                send_response(400, {'state': 'error', 'message': 'Port is missing'})
                return
            if not port.isdigit():
                send_response(400, {'state': 'error', 'message': 'Port is not a valid number'})
                return
            if(not('code' in data)):
                send_response(400, {'state': 'error', 'message': 'Code is missing'})
                return
            if(not('board' in data)):
                send_response(400, {'state': 'error', 'message': 'Board is missing'})        
                return
            
            result = compile_and_upload(f'COM{port}', data['board'], data['code'])
            if result['state'] == 'error':
                send_response(500, result)
                return
            send_response(200, result)    
                
        except json.JSONDecodeError:
            send_response(400, {'state': 'error', 'message': 'Invalid JSON'})
        
            

# if __name__ == '__main__':
#     server_address = ('localhost', 8080)
#     httpd = HTTPServer(server_address, SimplePostApiHandler)
#     print('Server running on http://localhost:8080')
#     httpd.serve_forever()

# Example function call
#port = "COM5"  # Example: COM5 or /dev/ttyUSB0
#fqbn = "esp8266:esp8266:d1_mini"  # Fully Qualified Board Name
#code = """void setup() {pinMode(D6, OUTPUT);}void loop() {digitalWrite(D6, HIGH);delay(1000);digitalWrite(D6, LOW);delay(1000);}"""
#print(compile_and_upload(port, fqbn, code))

def run_server():
    server_address = ('localhost', 8080)
    httpd = HTTPServer(server_address, SimplePostApiHandler)
    print('Server running on http://localhost:8080')
    httpd.serve_forever()

#Code that is executed after the GUI is opened
def main_code():
    server_thread = Thread(target=run_server, daemon=True)
    server_thread.start()
    
    state_label.configure(text="Bereit", fg="green")

root.after(0, main_code)    
root.mainloop()

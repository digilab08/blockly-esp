@echo off
python "%~dp0windows_upload_service.py"